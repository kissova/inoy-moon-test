#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:18 2026

// =============================================================================

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BuildSystem.BuildingActorBase.SpawnDestroyParticle
struct ABuildingActorBase_SpawnDestroyParticle_Params
{
	bool                                               bSpawnParticle;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  Loc;                                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FSoftObjectPath                             DestroyBuildingEffectPath;                                // (ConstParm, Parm, OutParm, ReferenceParm)
	class UWorld*                                      World;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.SetLastQuadTraceDeviation
struct ABuildingActorBase_SetLastQuadTraceDeviation_Params
{
	float                                              InDeviation;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.PlayDestroyAnimation
struct ABuildingActorBase_PlayDestroyAnimation_Params
{
	bool                                               bUseParticle;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.OnTakeDamageFromVehicle
struct ABuildingActorBase_OnTakeDamageFromVehicle_Params
{
	class UPrimitiveComponent*                         MyPrimitiveComp;                                          // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	float                                              ForwardSpeed;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DamageAmount;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      DamageCauser;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class AController*                                 EventInstigator;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.OnRep_Health
struct ABuildingActorBase_OnRep_Health_Params
{
};

// Function BuildSystem.BuildingActorBase.OnPlayDestroyAnimation
struct ABuildingActorBase_OnPlayDestroyAnimation_Params
{
	bool                                               bUseParticle;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.OnBuildingActorDamaged
struct ABuildingActorBase_OnBuildingActorDamaged_Params
{
	float                                              Health;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.OnBornAnimationPlayEndInClient
struct ABuildingActorBase_OnBornAnimationPlayEndInClient_Params
{
};

// Function BuildSystem.BuildingActorBase.GetLastQuadTraceDeviation
struct ABuildingActorBase_GetLastQuadTraceDeviation_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.GetBuildID
struct ABuildingActorBase_GetBuildID_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorBase.BPOnOwnerChanged
struct ABuildingActorBase_BPOnOwnerChanged_Params
{
};

// Function BuildSystem.BuildSystemComponent.TryAttachToMoveablePlatform
struct UBuildSystemComponent_TryAttachToMoveablePlatform_Params
{
	class AActor*                                      SpawnedBuilding;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     BuildLocation;                                            // (Parm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.ToggleDebugDraw
struct UBuildSystemComponent_ToggleDebugDraw_Params
{
};

// Function BuildSystem.BuildSystemComponent.StopPlaceBuilding
struct UBuildSystemComponent_StopPlaceBuilding_Params
{
};

// Function BuildSystem.BuildSystemComponent.StartPrePlaceBuilding
struct UBuildSystemComponent_StartPrePlaceBuilding_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AvatarID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	EBuildingViewType                                  viewType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.SkipCDTimeByBuildID
struct UBuildSystemComponent_SkipCDTimeByBuildID_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              IncreaseRate;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.ShouldEnableDoubleTouchMode
struct UBuildSystemComponent_ShouldEnableDoubleTouchMode_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.SetPrebuildEnabled
struct UBuildSystemComponent_SetPrebuildEnabled_Params
{
	bool                                               CanBePlaced;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsVisible;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.SetBuildingDataModeID
struct UBuildSystemComponent_SetBuildingDataModeID_Params
{
	int                                                ModeID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.SetBuildingData
struct UBuildSystemComponent_SetBuildingData_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBuildingData                               InData;                                                   // (Parm)
};

// Function BuildSystem.BuildSystemComponent.ServerLineTraceCheck
struct UBuildSystemComponent_ServerLineTraceCheck_Params
{
	class UClass*                                      BuildingClass;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     CheckLocation;                                            // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    CheckRotation;                                            // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.ResetBuildngCDByBuildID
struct UBuildSystemComponent_ResetBuildngCDByBuildID_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InNewCDTime;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.ResetBuildList
struct UBuildSystemComponent_ResetBuildList_Params
{
};

// Function BuildSystem.BuildSystemComponent.ProccessNothingHitTraceOverlap
struct UBuildSystemComponent_ProccessNothingHitTraceOverlap_Params
{
	struct FVector                                     DestLocation;                                             // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    DestRotation;                                             // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float                                              MaxBuildDist;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, IsPlainOldData)
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ViewLocation;                                             // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.PlaceBuildingWithIndex
struct UBuildSystemComponent_PlaceBuildingWithIndex_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AvatarID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRelative;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.PlaceBuildingAtLocation
struct UBuildSystemComponent_PlaceBuildingAtLocation_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Loc;                                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    Rot;                                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.PlaceBuilding
struct UBuildSystemComponent_PlaceBuilding_Params
{
	int                                                AvatarID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRelative;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.PickLocationByBuildID
struct UBuildSystemComponent_PickLocationByBuildID_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, IsPlainOldData)
	struct FRotator                                    OutRotation;                                              // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OverriveDeploymentTransform
struct UBuildSystemComponent_OverriveDeploymentTransform_Params
{
	struct FRotator                                    rotIn;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     locIn;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    rotOut;                                                   // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     locOut;                                                   // (Parm, OutParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OverrideBuildingMaxBuildDistance
struct UBuildSystemComponent_OverrideBuildingMaxBuildDistance_Params
{
	float                                              BuildingMaxDistance;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               SetAll;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                BuildingID;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBoxEnded
struct UBuildSystemComponent_OnTouchedConstructableBoxEnded_Params
{
	TEnumAsByte<enum ETouchIndex>                      FingerIndex;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent*                         TouchedComponent;                                         // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBox
struct UBuildSystemComponent_OnTouchedConstructableBox_Params
{
	TEnumAsByte<enum ETouchIndex>                      FingerIndex;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent*                         TouchedComponent;                                         // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnTouchActorBuild
struct UBuildSystemComponent_OnTouchActorBuild_Params
{
	struct FVector2D                                   ScreenPosition;                                           // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class APlayerController*                           Controller;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnAsyncLoadingMeshFinished
struct UBuildSystemComponent_OnAsyncLoadingMeshFinished_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnAsyncLoadingEffectFinished
struct UBuildSystemComponent_OnAsyncLoadingEffectFinished_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.OnAsyncLoadingBuildingFinished
struct UBuildSystemComponent_OnAsyncLoadingBuildingFinished_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsValidAvatar
struct UBuildSystemComponent_IsValidAvatar_Params
{
	int                                                AvatarID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsParticlePreBuildingEffect
struct UBuildSystemComponent_IsParticlePreBuildingEffect_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsOverlayBuildHeightValid
struct UBuildSystemComponent_IsOverlayBuildHeightValid_Params
{
	struct FVector                                     BuildLocation;                                            // (Parm, IsPlainOldData)
	float                                              OverlayMaxHeightFromGround;                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsInPreBuildingMode
struct UBuildSystemComponent_IsInPreBuildingMode_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsCanPlaceBuildingBP
struct UBuildSystemComponent_IsCanPlaceBuildingBP_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsCanPlaceBuilding
struct UBuildSystemComponent_IsCanPlaceBuilding_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBuildingActionType>              _TYPE;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.IsActorProhibited
struct UBuildSystemComponent_IsActorProhibited_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectRotation
struct UBuildSystemComponent_GetPreBuildingEffectRotation_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectPath
struct UBuildSystemComponent_GetPreBuildingEffectPath_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AvatarID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSoftObjectPath                             ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectOffset
struct UBuildSystemComponent_GetPreBuildingEffectOffset_Params
{
	int                                                InBuildID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetOwnerPlayerController
struct UBuildSystemComponent_GetOwnerPlayerController_Params
{
	class APlayerController*                           ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetMaxDistance
struct UBuildSystemComponent_GetMaxDistance_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetLastQuadTraceDeviation
struct UBuildSystemComponent_GetLastQuadTraceDeviation_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetIsHasInitData
struct UBuildSystemComponent_GetIsHasInitData_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetIndexByBuildingID
struct UBuildSystemComponent_GetIndexByBuildingID_Params
{
	int                                                BuildID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetCurrentBuildType
struct UBuildSystemComponent_GetCurrentBuildType_Params
{
	TEnumAsByte<enum EBuildingType>                    ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetCDOByIndex
struct UBuildSystemComponent_GetCDOByIndex_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.GetBuildingList
struct UBuildSystemComponent_GetBuildingList_Params
{
	TArray<struct FBuildingData>                       ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BuildSystem.BuildSystemComponent.GetBuildingDataModeID
struct UBuildSystemComponent_GetBuildingDataModeID_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.EnableBuildingByID
struct UBuildSystemComponent_EnableBuildingByID_Params
{
	int                                                BuildID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bEnable;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.DoSceenTouchBuild
struct UBuildSystemComponent_DoSceenTouchBuild_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ScreenPostion;                                            // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int                                                PointerIndex;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBuildingActionType>              _TYPE;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsBegin;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBuildingActionType>              CustomBuildEvent;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.DensityCheck
struct UBuildSystemComponent_DensityCheck_Params
{
	struct FBuildingActorDensityCheck                  DensityCheckParmas;                                       // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckShouldSkipByVisibility
struct UBuildSystemComponent_CheckShouldSkipByVisibility_Params
{
	class UPrimitiveComponent*                         _comp;                                                    // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckPlacementWithPitch
struct UBuildSystemComponent_CheckPlacementWithPitch_Params
{
	struct FHitResult                                  Hit;                                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    OutRotation;                                              // (Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     BoxExtent;                                                // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FBuildingData                               CurBuildData;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckPlacementOverlap
struct UBuildSystemComponent_CheckPlacementOverlap_Params
{
	TArray<struct FHitResult>                          HitArray;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     BoxExtent;                                                // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FBuildingData                               CurBuildData;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRotator                                    BuildRotation;                                            // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    ControlRot;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     ViewLocation;                                             // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool                                               HasForbiddenObject;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckPlaceBuildingWithIndex
struct UBuildSystemComponent_CheckPlaceBuildingWithIndex_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckObjectIsOneOfTheTemplate
struct UBuildSystemComponent_CheckObjectIsOneOfTheTemplate_Params
{
	class UObject*                                     Obj;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UClass*>                              _ActorFilterTemplates;                                    // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.CheckCollisionNeedSkipOwner
struct UBuildSystemComponent_CheckCollisionNeedSkipOwner_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.BuildAtWorldLoc
struct UBuildSystemComponent_BuildAtWorldLoc_Params
{
	int                                                buildIndex;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  tranx;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     EndLocation;                                              // (Parm, IsPlainOldData)
	bool                                               bUseTrace;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBuildingActionType>              BuildType;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildSystemComponent.AddBuildingData
struct UBuildSystemComponent_AddBuildingData_Params
{
	struct FBuildingData                               InData;                                                   // (Parm)
};

// Function BuildSystem.BuildingActorInterface.UseQuadTraceDeviationForSpawnOffset
struct UBuildingActorInterface_UseQuadTraceDeviationForSpawnOffset_Params
{
	struct FVector                                     BuildLocation;                                            // (Parm, IsPlainOldData)
	float                                              QuadTraceDeviation;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.UseFixedLocation
struct UBuildingActorInterface_UseFixedLocation_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.UseCachedBuildLocation
struct UBuildingActorInterface_UseCachedBuildLocation_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldUseExtraRotation
struct UBuildingActorInterface_ShouldUseExtraRotation_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldUseExtraOffset
struct UBuildingActorInterface_ShouldUseExtraOffset_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldSnapToGrid
struct UBuildingActorInterface_ShouldSnapToGrid_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldSkipCheckOwnerCollision
struct UBuildingActorInterface_ShouldSkipCheckOwnerCollision_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldCustomBlockingChannels
struct UBuildingActorInterface_ShouldCustomBlockingChannels_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldCheckVisibilityTypes
struct UBuildingActorInterface_ShouldCheckVisibilityTypes_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.ShouldAttachToMovementPlatform
struct UBuildingActorInterface_ShouldAttachToMovementPlatform_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.SetBuildingActorID
struct UBuildingActorInterface_SetBuildingActorID_Params
{
	int                                                BuildID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.PrebuildCDOBodyInstance
struct UBuildingActorInterface_PrebuildCDOBodyInstance_Params
{
	class UWorld*                                      World;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  tranx;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.NonCullingBeginPlay
struct UBuildingActorInterface_NonCullingBeginPlay_Params
{
};

// Function BuildSystem.BuildingActorInterface.MaxUnderWaterBuildDepth
struct UBuildingActorInterface_MaxUnderWaterBuildDepth_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.IsEnablePitchRotatePlace
struct UBuildingActorInterface_IsEnablePitchRotatePlace_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.IsEnableOverlayPlace
struct UBuildingActorInterface_IsEnableOverlayPlace_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.IsBuildOnlyOnLandscape
struct UBuildingActorInterface_IsBuildOnlyOnLandscape_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.IsBuildOnEdge
struct UBuildingActorInterface_IsBuildOnEdge_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.IsAutoPickValidPlace
struct UBuildingActorInterface_IsAutoPickValidPlace_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.HandleBuildingDestroyed
struct UBuildingActorInterface_HandleBuildingDestroyed_Params
{
	class AController*                                 InstigatedBy;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.HandleBuildingConstructed
struct UBuildingActorInterface_HandleBuildingConstructed_Params
{
	class AController*                                 InstigatedBy;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetWorldSnapSetup
struct UBuildingActorInterface_GetWorldSnapSetup_Params
{
	struct FBuildingActorWorldSnapSetup                ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetVisibilitySkipTypes
struct UBuildingActorInterface_GetVisibilitySkipTypes_Params
{
	TArray<class UClass*>                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetViewLocationOffset
struct UBuildingActorInterface_GetViewLocationOffset_Params
{
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetProhibitedActorTemplateList
struct UBuildingActorInterface_GetProhibitedActorTemplateList_Params
{
	TArray<class UClass*>                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectScale
struct UBuildingActorInterface_GetPreBuildingEffectScale_Params
{
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectRotation
struct UBuildingActorInterface_GetPreBuildingEffectRotation_Params
{
	struct FRotator                                    ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectPath
struct UBuildingActorInterface_GetPreBuildingEffectPath_Params
{
	struct FSoftObjectPath                             ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectOffset
struct UBuildingActorInterface_GetPreBuildingEffectOffset_Params
{
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetOverlayPlaceHeight
struct UBuildingActorInterface_GetOverlayPlaceHeight_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetOverlayMaxHeightFromGround
struct UBuildingActorInterface_GetOverlayMaxHeightFromGround_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetMaxTraceDepth
struct UBuildingActorInterface_GetMaxTraceDepth_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetMaxOffectHight
struct UBuildingActorInterface_GetMaxOffectHight_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetMaxDeviation
struct UBuildingActorInterface_GetMaxDeviation_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetDSBuildCheckConfig
struct UBuildingActorInterface_GetDSBuildCheckConfig_Params
{
	struct FBuildingActorDSBuildCheck                  ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetDetectDeath
struct UBuildingActorInterface_GetDetectDeath_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetDestroyedParticleTransformOffset
struct UBuildingActorInterface_GetDestroyedParticleTransformOffset_Params
{
	struct FTransform                                  ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetDensityParams
struct UBuildingActorInterface_GetDensityParams_Params
{
	struct FVector                                     Location;                                                 // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FBuildingActorDensityCheck                  ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetCustomBlockingChannels
struct UBuildingActorInterface_GetCustomBlockingChannels_Params
{
	TArray<TEnumAsByte<enum ECollisionChannel>>        ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BuildSystem.BuildingActorInterface.GetConstructingMode
struct UBuildingActorInterface_GetConstructingMode_Params
{
	TEnumAsByte<enum EBuildingActorConstructingMode>   ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetBuildOnEdgeUpLength
struct UBuildingActorInterface_GetBuildOnEdgeUpLength_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetBuildOnEdgeFrontLength
struct UBuildingActorInterface_GetBuildOnEdgeFrontLength_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetBuildingActorID
struct UBuildingActorInterface_GetBuildingActorID_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxRotator
struct UBuildingActorInterface_GetActorCollisionBoxRotator_Params
{
	struct FRotator                                    ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxExtern
struct UBuildingActorInterface_GetActorCollisionBoxExtern_Params
{
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxCenter
struct UBuildingActorInterface_GetActorCollisionBoxCenter_Params
{
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.CustomizeLocationAndRotation
struct UBuildingActorInterface_CustomizeLocationAndRotation_Params
{
	class AActor*                                      Builder;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InLocation;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    InRotation;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutLocation;                                              // (Parm, OutParm, IsPlainOldData)
	struct FRotator                                    OutRotation;                                              // (Parm, OutParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.CanDoQuadTrace
struct UBuildingActorInterface_CanDoQuadTrace_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.CanCustomizeLocationAndRotation
struct UBuildingActorInterface_CanCustomizeLocationAndRotation_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.CanBuildUnderWater
struct UBuildingActorInterface_CanBuildUnderWater_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.BPCheckPlacement
struct UBuildingActorInterface_BPCheckPlacement_Params
{
	class UWorld*                                      World;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  tranx;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int                                                CheckType;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CurrentAvatarID;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Builder;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorInterface.BP_DSFinalCheckPlacement
struct UBuildingActorInterface_BP_DSFinalCheckPlacement_Params
{
	struct FTransform                                  Transform;                                                // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AActor*                                      Builder;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.BuildingActorMgr.OnBuildingActorSpawned
struct ABuildingActorMgr_OnBuildingActorSpawned_Params
{
	class AActor*                                      InOwnerActor;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class ABuildingActorBase*                          InBuildingActor;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorMgr.OnBuildingActorDestroyed
struct ABuildingActorMgr_OnBuildingActorDestroyed_Params
{
	class ABuildingActorBase*                          InBuildingActor;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.BuildingActorMgr.GetInstance
struct ABuildingActorMgr_GetInstance_Params
{
	class UObject*                                     WorldContextObject;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class ABuildingActorMgr*                           ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetSelectActorTemplateScale
struct ASelectBuildActor_SetSelectActorTemplateScale_Params
{
	struct FVector                                     inScale;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetSelectActorTemplateOffsetAndRotation
struct ASelectBuildActor_SetSelectActorTemplateOffsetAndRotation_Params
{
	struct FVector                                     InOffset;                                                 // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    InRotation;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetSelectActorTemplate
struct ASelectBuildActor_SetSelectActorTemplate_Params
{
	class UParticleSystem*                             Template;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetSelectActorPlacementEnable
struct ASelectBuildActor_SetSelectActorPlacementEnable_Params
{
	bool                                               PlacementEnable;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsVisible;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetSelectActorMesh
struct ASelectBuildActor_SetSelectActorMesh_Params
{
	class UStaticMesh*                                 InMesh;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.SetIsPlacementEnable
struct ASelectBuildActor_SetIsPlacementEnable_Params
{
	bool                                               Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.OnParticleLoaded
struct ASelectBuildActor_OnParticleLoaded_Params
{
};

// Function BuildSystem.SelectBuildActor.IsCurrentPlacementEnable
struct ASelectBuildActor_IsCurrentPlacementEnable_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.GetIsPlacementEnable
struct ASelectBuildActor_GetIsPlacementEnable_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BuildSystem.SelectBuildActor.GetIsParticleEffect
struct ASelectBuildActor_GetIsParticleEffect_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

