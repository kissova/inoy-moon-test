#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:18 2026

// =============================================================================

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Basic.UAENetActor.ReceivedPlayerActiveRegionsChanged
struct AUAENetActor_ReceivedPlayerActiveRegionsChanged_Params
{
	bool                                               bEnter;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.ItemHandleBase.SetAssociation
struct UItemHandleBase_SetAssociation_Params
{
	int                                                AssociationType;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FItemAssociation                            Association;                                              // (Parm)
};

// Function Basic.ItemHandleBase.RemoveAssociation
struct UItemHandleBase_RemoveAssociation_Params
{
	int                                                AssociationType;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.ItemHandleBase.Init
struct UItemHandleBase_Init_Params
{
	struct FItemDefineID                               InDefineID;                                               // (Parm)
};

// Function Basic.ItemHandleBase.GetDefineID
struct UItemHandleBase_GetDefineID_Params
{
	struct FItemDefineID                               ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.ItemHandleBase.GetAssociationMap
struct UItemHandleBase_GetAssociationMap_Params
{
	TMap<int, struct FItemAssociation>                 ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.ItemHandleBase.GetAssociationListByTargetType
struct UItemHandleBase_GetAssociationListByTargetType_Params
{
	int                                                Type;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FItemAssociation>                    ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.ItemHandleBase.GetAssociationByTargetDefineID
struct UItemHandleBase_GetAssociationByTargetDefineID_Params
{
	struct FItemDefineID                               TargetDefineID;                                           // (Parm)
	struct FItemAssociation                            ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.ItemHandleBase.GetAssociation
struct UItemHandleBase_GetAssociation_Params
{
	int                                                AssociationType;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FItemAssociation                            ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.ItemHandleBase.Constuct
struct UItemHandleBase_Constuct_Params
{
	struct FItemDefineID                               InDefineID;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Basic.ItemHandleBase.CollectionNeedLoadSoftPath
struct UItemHandleBase_CollectionNeedLoadSoftPath_Params
{
	TArray<struct FSoftObjectPath>                     OutSoftPathList;                                          // (Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.ItemHandleBase.AddAssociation
struct UItemHandleBase_AddAssociation_Params
{
	int                                                AssociationType;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FItemAssociation                            Association;                                              // (Parm)
};

// Function Basic.BattleItemHandleBase.UpdateAttributeModify
struct UBattleItemHandleBase_UpdateAttributeModify_Params
{
	bool                                               bEnable;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.UnEquip
struct UBattleItemHandleBase_UnEquip_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.ShouldDropInDisuse
struct UBattleItemHandleBase_ShouldDropInDisuse_Params
{
	TScriptInterface<class UItemContainerInterface>    ItemContainer;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FItemDefineID                               CurrentPickupItemDefineID;                                // (Parm)
	struct FItemDefineID                               ThisItemDefineID;                                         // (Parm)
	int                                                KeptCount;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	EBattleItemDisuseReason                            Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HanldePickupAssociationData
struct UBattleItemHandleBase_HanldePickupAssociationData_Params
{
	TArray<struct FBattleItemAdditionalData>           PickupAdditionalData;                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HanldeDropAssociationData
struct UBattleItemHandleBase_HanldeDropAssociationData_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HanldeCleared
struct UBattleItemHandleBase_HanldeCleared_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleUse
struct UBattleItemHandleBase_HandleUse_Params
{
	struct FBattleItemUseTarget                        Target;                                                   // (Parm)
	EBattleItemUseReason                               Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandlePickup
struct UBattleItemHandleBase_HandlePickup_Params
{
	TScriptInterface<class UItemContainerInterface>    ItemContainer;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FBattleItemPickupInfo                       PickupInfo;                                               // (Parm)
	EBattleItemPickupReason                            Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleEnable
struct UBattleItemHandleBase_HandleEnable_Params
{
	bool                                               bEnable;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleDrop
struct UBattleItemHandleBase_HandleDrop_Params
{
	int                                                InCount;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	EBattleItemDropReason                              Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleDisuse
struct UBattleItemHandleBase_HandleDisuse_Params
{
	EBattleItemDisuseReason                            Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleChangeItemStoreArea
struct UBattleItemHandleBase_HandleChangeItemStoreArea_Params
{
	EItemStoreArea                                     InItemStoreArea;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.HandleBindToTargetItem
struct UBattleItemHandleBase_HandleBindToTargetItem_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.GetWorldInternal
struct UBattleItemHandleBase_GetWorldInternal_Params
{
	class UWorld*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.GetCurrentWorld
struct UBattleItemHandleBase_GetCurrentWorld_Params
{
	class UWorld*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.ExtractItemData
struct UBattleItemHandleBase_ExtractItemData_Params
{
	struct FBattleItemData                             ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.BattleItemHandleBase.ClearAdditionalDataByType
struct UBattleItemHandleBase_ClearAdditionalDataByType_Params
{
	EBattleItemAdditionalDataType                      DataType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.BattleItemHandleBase.ClearAdditionalData
struct UBattleItemHandleBase_ClearAdditionalData_Params
{
};

// Function Basic.BattleItemHandleBase.CheckCanUse
struct UBattleItemHandleBase_CheckCanUse_Params
{
	TScriptInterface<class UItemContainerInterface>    ItemContainer;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FBattleItemUseTarget                        Target;                                                   // (Parm)
	EBattleItemUseReason                               Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.SetModeID
struct UUAEGameInstance_SetModeID_Params
{
	int                                                InModeID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UAEGameInstance.SetLuaStateWrapper
struct UUAEGameInstance_SetLuaStateWrapper_Params
{
	class ULuaStateWrapper*                            TLuaStateWrapper;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UAEGameInstance.SetExtraModules
struct UUAEGameInstance_SetExtraModules_Params
{
	TArray<struct FString>                             InExtraModules;                                           // (Parm, ZeroConstructor)
};

// Function Basic.UAEGameInstance.OpenAssetLoadLog
struct UUAEGameInstance_OpenAssetLoadLog_Params
{
};

// DelegateFunction Basic.UAEGameInstance.OnPreBattleResult__DelegateSignature
struct UUAEGameInstance_OnPreBattleResult__DelegateSignature_Params
{
};

// Function Basic.UAEGameInstance.LuaLeakDetect
struct UUAEGameInstance_LuaLeakDetect_Params
{
};

// Function Basic.UAEGameInstance.LuaDoString
struct UUAEGameInstance_LuaDoString_Params
{
	struct FString                                     LuaString;                                                // (Parm, ZeroConstructor)
};

// Function Basic.UAEGameInstance.GetWeatherTime
struct UUAEGameInstance_GetWeatherTime_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetWeatherLevelName
struct UUAEGameInstance_GetWeatherLevelName_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetWeatherID
struct UUAEGameInstance_GetWeatherID_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetModType2
struct UUAEGameInstance_GetModType2_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetModType
struct UUAEGameInstance_GetModType_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetModeID
struct UUAEGameInstance_GetModeID_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetLuaStateWrapper
struct UUAEGameInstance_GetLuaStateWrapper_Params
{
	class ULuaStateWrapper*                            ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetLoadWeatherName
struct UUAEGameInstance_GetLoadWeatherName_Params
{
	struct FString                                     InWeatherName;                                            // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetIsHighWeatherLevel
struct UUAEGameInstance_GetIsHighWeatherLevel_Params
{
	struct FString                                     InWeatherLevelName;                                       // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetGameID
struct UUAEGameInstance_GetGameID_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetExtraModulesString
struct UUAEGameInstance_GetExtraModulesString_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetExtraModules
struct UUAEGameInstance_GetExtraModules_Params
{
	TArray<struct FString>                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEGameInstance.GetDeviceLevel
struct UUAEGameInstance_GetDeviceLevel_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetDataTable_Mod
struct UUAEGameInstance_GetDataTable_Mod_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetDataTable
struct UUAEGameInstance_GetDataTable_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.GetAssociatedFrontendHUD
struct UUAEGameInstance_GetAssociatedFrontendHUD_Params
{
	class UFrontendHUD*                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEGameInstance.CloseAssetLoadLog
struct UUAEGameInstance_CloseAssetLoadLog_Params
{
};

// Function Basic.AttrModifyComponent.SwitchAttrModifierByIndex
struct UAttrModifyComponent_SwitchAttrModifierByIndex_Params
{
	int                                                ModifyConfigIndex;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Enable;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SwitchAttrModifier
struct UAttrModifyComponent_SwitchAttrModifier_Params
{
	struct FString                                     AttrModifyItemName;                                       // (Parm, ZeroConstructor)
	bool                                               Enable;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.StartTimerToSyncRecordAttrValue
struct UAttrModifyComponent_StartTimerToSyncRecordAttrValue_Params
{
	float                                              Time;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetValueToAttributeSafety
struct UAttrModifyComponent_SetValueToAttributeSafety_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ModifyRecordType;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetOrignalValueToAttribute
struct UAttrModifyComponent_SetOrignalValueToAttribute_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetOrignalValueAndBaseValue
struct UAttrModifyComponent_SetOrignalValueAndBaseValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetAttrModifyStateValue
struct UAttrModifyComponent_SetAttrModifyStateValue_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetAttributeMinValue
struct UAttrModifyComponent_SetAttributeMinValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              MinValue;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.SetAttributeMaxValue
struct UAttrModifyComponent_SetAttributeMaxValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              MaxValue;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.ServerSendExceptionType
struct UAttrModifyComponent_ServerSendExceptionType_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	int                                                ExceptionType;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.ServerRequestRecordAttrValue
struct UAttrModifyComponent_ServerRequestRecordAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.AttrModifyComponent.ResponeAttrValue
struct UAttrModifyComponent_ResponeAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              FinalValue;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.RequestAttrValue
struct UAttrModifyComponent_RequestAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.AttrModifyComponent.RemoveModifyItemFromCache
struct UAttrModifyComponent_RemoveModifyItemFromCache_Params
{
	uint32_t                                           ModifyUID;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.RemoveAttrListener
struct UAttrModifyComponent_RemoveAttrListener_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	struct FSluaBPVar                                  Listener;                                                 // (Parm)
};

// Function Basic.AttrModifyComponent.RemoveAllDynamicModifier
struct UAttrModifyComponent_RemoveAllDynamicModifier_Params
{
	bool                                               bForce;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.RegisterModifyAbleAttr
struct UAttrModifyComponent_RegisterModifyAbleAttr_Params
{
	TArray<struct FAttrRegisterItem>                   AttrRegists;                                              // (Parm, OutParm, ZeroConstructor)
	bool                                               bSetAttrByOrigin;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.RegistAttrModifyRecordList
struct UAttrModifyComponent_RegistAttrModifyRecordList_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	int                                                RecordLen;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.RegCurrentModAttrs
struct UAttrModifyComponent_RegCurrentModAttrs_Params
{
};

// Function Basic.AttrModifyComponent.RefreshAttributeModify
struct UAttrModifyComponent_RefreshAttributeModify_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.AttrModifyComponent.PushAttrModifyRecordItem
struct UAttrModifyComponent_PushAttrModifyRecordItem_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              PreValue;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CurValue;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ModifyRecordType;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ModifyDesc;                                               // (Parm, ZeroConstructor)
};

// Function Basic.AttrModifyComponent.OnRep_ModSimulateSyncList
struct UAttrModifyComponent_OnRep_ModSimulateSyncList_Params
{
};

// Function Basic.AttrModifyComponent.OnRep_ExceptionAttrModifyRecords
struct UAttrModifyComponent_OnRep_ExceptionAttrModifyRecords_Params
{
};

// Function Basic.AttrModifyComponent.OnRep_DynamicModifier
struct UAttrModifyComponent_OnRep_DynamicModifier_Params
{
};

// Function Basic.AttrModifyComponent.OnRep_AttrModifyStateList
struct UAttrModifyComponent_OnRep_AttrModifyStateList_Params
{
};

// DelegateFunction Basic.AttrModifyComponent.OnNeedSetSpeedOverLimit__DelegateSignature
struct UAttrModifyComponent_OnNeedSetSpeedOverLimit__DelegateSignature_Params
{
};

// DelegateFunction Basic.AttrModifyComponent.OnAttrModifiedEvent__DelegateSignature
struct UAttrModifyComponent_OnAttrModifiedEvent__DelegateSignature_Params
{
	TArray<struct FAttrAffected>                       AffectedAttrS;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.AttrModifyComponent.LuaSetValueToAttributeSafety
struct UAttrModifyComponent_LuaSetValueToAttributeSafety_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.IsAttrModifyStateValidIndex
struct UAttrModifyComponent_IsAttrModifyStateValidIndex_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.InitializeRelateAttributeExpands
struct UAttrModifyComponent_InitializeRelateAttributeExpands_Params
{
};

// Function Basic.AttrModifyComponent.HasDynamicModifier
struct UAttrModifyComponent_HasDynamicModifier_Params
{
	struct FString                                     AttrModifyId;                                             // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.HandleExceptionAttrModify
struct UAttrModifyComponent_HandleExceptionAttrModify_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	int                                                ExceptionType;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetSubsystem
struct UAttrModifyComponent_GetSubsystem_Params
{
	class UAttrModifyModDataSubsystem*                 ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetMaxAttrName
struct UAttrModifyComponent_GetMaxAttrName_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.AttrModifyComponent.GetAttrModifyStateValue
struct UAttrModifyComponent_GetAttrModifyStateValue_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetAttrModifyStateNum
struct UAttrModifyComponent_GetAttrModifyStateNum_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetAttrModifyItemByItemName
struct UAttrModifyComponent_GetAttrModifyItemByItemName_Params
{
	struct FString                                     ItemName;                                                 // (Parm, ZeroConstructor)
	struct FAttrModifyItem                             ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.AttrModifyComponent.GetAttributeValue
struct UAttrModifyComponent_GetAttributeValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetAttributeOrignalValue
struct UAttrModifyComponent_GetAttributeOrignalValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetAttributeMaxValue
struct UAttrModifyComponent_GetAttributeMaxValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.GetAttrDynamicModifyTargetString
struct UAttrModifyComponent_GetAttrDynamicModifyTargetString_Params
{
	struct FAttrDynamicModifyTarget                    DynamicModifyTarget;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.AttrModifyComponent.GetAttrDynamicModifyItemString
struct UAttrModifyComponent_GetAttrDynamicModifyItemString_Params
{
	struct FAttrDynamicModifyItem                      DynamicModifyItem;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.AttrModifyComponent.EnableAttrModifierByIndex
struct UAttrModifyComponent_EnableAttrModifierByIndex_Params
{
	int                                                ModifyConfigIndex;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.EnableAttrModifier
struct UAttrModifyComponent_EnableAttrModifier_Params
{
	struct FString                                     AttrModifyItemName;                                       // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.DisableAttrModifierByIndex
struct UAttrModifyComponent_DisableAttrModifierByIndex_Params
{
	int                                                ModifyConfigIndex;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.DisableAttrModifier
struct UAttrModifyComponent_DisableAttrModifier_Params
{
	struct FString                                     AttrModifyItemName;                                       // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.DisableAllAttrModifier
struct UAttrModifyComponent_DisableAllAttrModifier_Params
{
	bool                                               bForce;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.ConditionSyncRecordAttrValue
struct UAttrModifyComponent_ConditionSyncRecordAttrValue_Params
{
};

// Function Basic.AttrModifyComponent.ClientSyncRecordAttrValue
struct UAttrModifyComponent_ClientSyncRecordAttrValue_Params
{
	TArray<struct FAttrDesc>                           AttrDescs;                                                // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function Basic.AttrModifyComponent.ClientSendRecordData
struct UAttrModifyComponent_ClientSendRecordData_Params
{
	struct FAttrModifyRecordItem                       RecordItem;                                               // (ConstParm, Parm, ReferenceParm)
	int                                                ExceptionType;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.ClearAllAttrModify
struct UAttrModifyComponent_ClearAllAttrModify_Params
{
};

// Function Basic.AttrModifyComponent.AddValueToAttribute
struct UAttrModifyComponent_AddValueToAttribute_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.AddModifyItemAndCache
struct UAttrModifyComponent_AddModifyItemAndCache_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	EAttrModifyRefType                                 CModifyType;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CValue;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bEnable;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bOldModify;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.AddDynamicModifier
struct UAttrModifyComponent_AddDynamicModifier_Params
{
	struct FAttrModifyItem                             AttrModifyItem;                                           // (Parm, OutParm)
	bool                                               RepOnlyOwner;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.AddBModifyAndCacheWithCParam
struct UAttrModifyComponent_AddBModifyAndCacheWithCParam_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	EAttrModifyRefType                                 CModifyType;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CValue;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ClientSimulate;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.AddBModifyAndCache
struct UAttrModifyComponent_AddBModifyAndCache_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	EAttrOperator                                      ModifyType;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ClientSimulate;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyComponent.AddAttrListener
struct UAttrModifyComponent_AddAttrListener_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	struct FSluaBPVar                                  Listener;                                                 // (Parm)
};

// Function Basic.AttrModifyInterface.SetAttrValue
struct UAttrModifyInterface_SetAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              NewVal;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.AttrModifyInterface.RequestAttrValue
struct UAttrModifyInterface_RequestAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.AttrModifyInterface.RegisterModifiedAttributes
struct UAttrModifyInterface_RegisterModifiedAttributes_Params
{
};

// Function Basic.AttrModifyInterface.GetAttrValue
struct UAttrModifyInterface_GetAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyInterface.GetAttrModifyRelevantActors
struct UAttrModifyInterface_GetAttrModifyRelevantActors_Params
{
	TArray<class AActor*>                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.AttrModifyInterface.GetAttrModifyComponent
struct UAttrModifyInterface_GetAttrModifyComponent_Params
{
	class UAttrModifyComponent*                        ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.AttrModifyInterface.GetAttributeValue
struct UAttrModifyInterface_GetAttributeValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.AttrModifyInterface.AddAttrValue
struct UAttrModifyInterface_AddAttrValue_Params
{
	struct FString                                     AttrName;                                                 // (Parm, ZeroConstructor)
	float                                              AddVal;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.BPClassManager.ModifyClass
struct UBPClassManager_ModifyClass_Params
{
	class UClass*                                      InNativeClass;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     BPClassPath;                                              // (Parm, ZeroConstructor)
	struct FString                                     ModTag;                                                   // (Parm, ZeroConstructor)
};

// Function Basic.BPClassManager.GetUClass
struct UBPClassManager_GetUClass_Params
{
	int                                                KeyIndex;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPClassManager.GetBPClassOverrideByName
struct UBPClassManager_GetBPClassOverrideByName_Params
{
	struct FString                                     ClassTagName;                                             // (Parm, ZeroConstructor)
	struct FString                                     ModTag;                                                   // (Parm, ZeroConstructor)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPClassManager.GetBPClassOverride
struct UBPClassManager_GetBPClassOverride_Params
{
	class UClass*                                      InNativeClass;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ModTag;                                                   // (Parm, ZeroConstructor)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPClassManager.Get
struct UBPClassManager_Get_Params
{
	class UBPClassManager*                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BuffConfigSubsystem.ReloadTable
struct UBuffConfigSubsystem_ReloadTable_Params
{
	class UWorld*                                      World;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.BuffConfigSubsystem.ClearTable
struct UBuffConfigSubsystem_ClearTable_Params
{
};

// Function Basic.BuffUtils.IsRoleOK
struct UBuffUtils_IsRoleOK_Params
{
	EBuffEnabledRole                                   EnabledRole;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UActorComponent*                             OwnerComponent;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetVectorArray
struct UCommonMessageDataLibrary_SetVectorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetVector4Array
struct UCommonMessageDataLibrary_SetVector4Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector4>                            Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetVector4
struct UCommonMessageDataLibrary_SetVector4_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector4                                    Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetVector2DArray
struct UCommonMessageDataLibrary_SetVector2DArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector2D>                           Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetVector2D
struct UCommonMessageDataLibrary_SetVector2D_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetVector
struct UCommonMessageDataLibrary_SetVector_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetTransformArray
struct UCommonMessageDataLibrary_SetTransformArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FTransform>                          Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetTransform
struct UCommonMessageDataLibrary_SetTransform_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetStringArray
struct UCommonMessageDataLibrary_SetStringArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetString
struct UCommonMessageDataLibrary_SetString_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     Value;                                                    // (Parm, ZeroConstructor)
};

// Function Basic.CommonMessageDataLibrary.SetRotatorArray
struct UCommonMessageDataLibrary_SetRotatorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRotator>                            Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetRotator
struct UCommonMessageDataLibrary_SetRotator_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetQuatArray
struct UCommonMessageDataLibrary_SetQuatArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FQuat>                               Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetQuat
struct UCommonMessageDataLibrary_SetQuat_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Value;                                                    // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetObjectArray
struct UCommonMessageDataLibrary_SetObjectArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UObject*>                             Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetObject
struct UCommonMessageDataLibrary_SetObject_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetNameArray
struct UCommonMessageDataLibrary_SetNameArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetName
struct UCommonMessageDataLibrary_SetName_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetLinearColorArray
struct UCommonMessageDataLibrary_SetLinearColorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FLinearColor>                        Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetLinearColor
struct UCommonMessageDataLibrary_SetLinearColor_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Value;                                                    // (Parm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetIntVectorArray
struct UCommonMessageDataLibrary_SetIntVectorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FIntVector>                          Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetIntVector
struct UCommonMessageDataLibrary_SetIntVector_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector                                  Value;                                                    // (Parm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetIntPointArray
struct UCommonMessageDataLibrary_SetIntPointArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FIntPoint>                           Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetIntPoint
struct UCommonMessageDataLibrary_SetIntPoint_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntPoint                                   Value;                                                    // (Parm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetInt64Array
struct UCommonMessageDataLibrary_SetInt64Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int64_t>                                    Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetInt64
struct UCommonMessageDataLibrary_SetInt64_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetInt32Array
struct UCommonMessageDataLibrary_SetInt32Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetInt32
struct UCommonMessageDataLibrary_SetInt32_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetFloatArray
struct UCommonMessageDataLibrary_SetFloatArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetFloat
struct UCommonMessageDataLibrary_SetFloat_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetColorArray
struct UCommonMessageDataLibrary_SetColorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FColor>                              Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetColor
struct UCommonMessageDataLibrary_SetColor_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FColor                                      Value;                                                    // (Parm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetClassArray
struct UCommonMessageDataLibrary_SetClassArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UClass*>                              Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetClass
struct UCommonMessageDataLibrary_SetClass_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetByteArray
struct UCommonMessageDataLibrary_SetByteArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetByte
struct UCommonMessageDataLibrary_SetByte_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetBoolArray
struct UCommonMessageDataLibrary_SetBoolArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<bool>                                       Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetBool
struct UCommonMessageDataLibrary_SetBool_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.SetActorArray
struct UCommonMessageDataLibrary_SetActorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*>                              Values;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.SetActor
struct UCommonMessageDataLibrary_SetActor_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Value;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.Remove
struct UCommonMessageDataLibrary_Remove_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVectorArray
struct UCommonMessageDataLibrary_GetVectorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVector4Array
struct UCommonMessageDataLibrary_GetVector4Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector4>                            OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVector4
struct UCommonMessageDataLibrary_GetVector4_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector4                                    OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVector2DArray
struct UCommonMessageDataLibrary_GetVector2DArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector2D>                           OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVector2D
struct UCommonMessageDataLibrary_GetVector2D_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetVector
struct UCommonMessageDataLibrary_GetVector_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetTransformArray
struct UCommonMessageDataLibrary_GetTransformArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FTransform>                          OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetTransform
struct UCommonMessageDataLibrary_GetTransform_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetStringArray
struct UCommonMessageDataLibrary_GetStringArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetString
struct UCommonMessageDataLibrary_GetString_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     OutValue;                                                 // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetRotatorArray
struct UCommonMessageDataLibrary_GetRotatorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRotator>                            OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetRotator
struct UCommonMessageDataLibrary_GetRotator_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetQuatArray
struct UCommonMessageDataLibrary_GetQuatArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FQuat>                               OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetQuat
struct UCommonMessageDataLibrary_GetQuat_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetObjectArray
struct UCommonMessageDataLibrary_GetObjectArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UObject*>                             OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetObject
struct UCommonMessageDataLibrary_GetObject_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetNameArray
struct UCommonMessageDataLibrary_GetNameArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetName
struct UCommonMessageDataLibrary_GetName_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetLinearColorArray
struct UCommonMessageDataLibrary_GetLinearColorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FLinearColor>                        OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetLinearColor
struct UCommonMessageDataLibrary_GetLinearColor_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetIntVectorArray
struct UCommonMessageDataLibrary_GetIntVectorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FIntVector>                          OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetIntVector
struct UCommonMessageDataLibrary_GetIntVector_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector                                  OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetIntPointArray
struct UCommonMessageDataLibrary_GetIntPointArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FIntPoint>                           OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetIntPoint
struct UCommonMessageDataLibrary_GetIntPoint_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntPoint                                   OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetInt64Array
struct UCommonMessageDataLibrary_GetInt64Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int64_t>                                    OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetInt64
struct UCommonMessageDataLibrary_GetInt64_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetInt32Array
struct UCommonMessageDataLibrary_GetInt32Array_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetInt32
struct UCommonMessageDataLibrary_GetInt32_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetFloatArray
struct UCommonMessageDataLibrary_GetFloatArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetFloat
struct UCommonMessageDataLibrary_GetFloat_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetEmptyCommonMessageData
struct UCommonMessageDataLibrary_GetEmptyCommonMessageData_Params
{
	struct FCommonMessageData                          ReturnValue;                                              // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function Basic.CommonMessageDataLibrary.GetColorArray
struct UCommonMessageDataLibrary_GetColorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FColor>                              OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetColor
struct UCommonMessageDataLibrary_GetColor_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FColor                                      OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetClassArray
struct UCommonMessageDataLibrary_GetClassArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UClass*>                              OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetClass
struct UCommonMessageDataLibrary_GetClass_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetByteArray
struct UCommonMessageDataLibrary_GetByteArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetByte
struct UCommonMessageDataLibrary_GetByte_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetBoolArray
struct UCommonMessageDataLibrary_GetBoolArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<bool>                                       OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetBool
struct UCommonMessageDataLibrary_GetBool_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetActorArray
struct UCommonMessageDataLibrary_GetActorArray_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*>                              OutValues;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.GetActor
struct UCommonMessageDataLibrary_GetActor_Params
{
	struct FCommonMessageData                          Target;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.CommonMessageDataLibrary.Clear
struct UCommonMessageDataLibrary_Clear_Params
{
	struct FCommonMessageData                          Target;                                                   // (Parm, OutParm, ReferenceParm)
};

// Function Basic.DelayReplicationInterface.ReSendRPCAfterBeginPlay
struct UDelayReplicationInterface_ReSendRPCAfterBeginPlay_Params
{
};

// Function Basic.DelayReplicationInterface.ReCallRepAfterBeginPlay
struct UDelayReplicationInterface_ReCallRepAfterBeginPlay_Params
{
};

// Function Basic.EnvLuaVMFactory.CreateEnvLuaVM
struct UEnvLuaVMFactory_CreateEnvLuaVM_Params
{
	struct FString                                     InLuaFilePath;                                            // (Parm, ZeroConstructor)
	class UObject*                                     WorldContextObject;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UEnvLuaVM*                                   ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.GameModeEnvUtil.GetModeID
struct UGameModeEnvUtil_GetModeID_Params
{
	struct FString                                     GameModeClassPath;                                        // (Parm, ZeroConstructor)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.GameModeEnvUtil.GetGameModeEnvData
struct UGameModeEnvUtil_GetGameModeEnvData_Params
{
	int                                                InModeID;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FGameModeEnvData                            OutData;                                                  // (Parm, OutParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushVectorModify
struct UStackModifyAttrInterface_PushVectorModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushVector4Modify
struct UStackModifyAttrInterface_PushVector4Modify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector4                                    InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushVector2DModify
struct UStackModifyAttrInterface_PushVector2DModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   InValue;                                                  // (Parm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushTransformModify
struct UStackModifyAttrInterface_PushTransformModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushStringModify
struct UStackModifyAttrInterface_PushStringModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     InValue;                                                  // (Parm, ZeroConstructor)
};

// Function Basic.StackModifyAttrInterface.PushRotatorModify
struct UStackModifyAttrInterface_PushRotatorModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushQuatModify
struct UStackModifyAttrInterface_PushQuatModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushNameModify
struct UStackModifyAttrInterface_PushNameModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushLinearColorModify
struct UStackModifyAttrInterface_PushLinearColorModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                InValue;                                                  // (Parm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushIntVectorModify
struct UStackModifyAttrInterface_PushIntVectorModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector                                  InValue;                                                  // (Parm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushIntPointModify
struct UStackModifyAttrInterface_PushIntPointModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntPoint                                   InValue;                                                  // (Parm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushInt32Modify
struct UStackModifyAttrInterface_PushInt32Modify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushFloatModify
struct UStackModifyAttrInterface_PushFloatModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushColorModify
struct UStackModifyAttrInterface_PushColorModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FColor                                      InValue;                                                  // (Parm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushByteModify
struct UStackModifyAttrInterface_PushByteModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PushBoolModify
struct UStackModifyAttrInterface_PushBoolModify_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.PopStackModifyAttr
struct UStackModifyAttrInterface_PopStackModifyAttr_Params
{
	int                                                ModifyKey;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.HasStackModify
struct UStackModifyAttrInterface_HasStackModify_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedVector4
struct UStackModifyAttrInterface_GetModifiedVector4_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector4                                    OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FVector4                                    ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedVector2D
struct UStackModifyAttrInterface_GetModifiedVector2D_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FVector2D                                   ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedVector
struct UStackModifyAttrInterface_GetModifiedVector_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FVector                                     ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedTransform
struct UStackModifyAttrInterface_GetModifiedTransform_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FTransform                                  ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedString
struct UStackModifyAttrInterface_GetModifiedString_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     OriginalValue;                                            // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.StackModifyAttrInterface.GetModifiedRotator
struct UStackModifyAttrInterface_GetModifiedRotator_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FRotator                                    ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedQuat
struct UStackModifyAttrInterface_GetModifiedQuat_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FQuat                                       ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedName
struct UStackModifyAttrInterface_GetModifiedName_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       OriginalValue;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedLinearColor
struct UStackModifyAttrInterface_GetModifiedLinearColor_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FLinearColor                                ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedIntVector
struct UStackModifyAttrInterface_GetModifiedIntVector_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector                                  OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FIntVector                                  ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedIntPoint
struct UStackModifyAttrInterface_GetModifiedIntPoint_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntPoint                                   OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FIntPoint                                   ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedInt32
struct UStackModifyAttrInterface_GetModifiedInt32_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                OriginalValue;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedFloat
struct UStackModifyAttrInterface_GetModifiedFloat_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OriginalValue;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedColor
struct UStackModifyAttrInterface_GetModifiedColor_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FColor                                      OriginalValue;                                            // (Parm, IsPlainOldData)
	struct FColor                                      ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedByte
struct UStackModifyAttrInterface_GetModifiedByte_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      OriginalValue;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.StackModifyAttrInterface.GetModifiedBool
struct UStackModifyAttrInterface_GetModifiedBool_Params
{
	struct FName                                       PropertyName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               OriginalValue;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.ItemContainerInterface.GetOwningObject
struct UItemContainerInterface_GetOwningObject_Params
{
	class UObject*                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.ItemContainerInterface.GetItemHandleListByDefineID
struct UItemContainerInterface_GetItemHandleListByDefineID_Params
{
	struct FItemDefineID                               DefineID;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<class UItemHandleBase*>                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.ItemContainerInterface.GetItemHandleByDefineID
struct UItemContainerInterface_GetItemHandleByDefineID_Params
{
	struct FItemDefineID                               DefineID;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	class UItemHandleBase*                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.ItemContainerInterface.GetItemDefineIDList
struct UItemContainerInterface_GetItemDefineIDList_Params
{
	TArray<struct FItemDefineID>                       ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.ItemContainerInterface.GetFirstItemDefineBySpecificID
struct UItemContainerInterface_GetFirstItemDefineBySpecificID_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FItemDefineID                               ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.ItemContainerOwnerInterface.NotifyUpdateCustomAccessoriesData
struct UItemContainerOwnerInterface_NotifyUpdateCustomAccessoriesData_Params
{
	int                                                WeaponItemId;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ItemId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsSetOrRemove;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.ItemContainerOwnerInterface.NotifyUpdateCapacity
struct UItemContainerOwnerInterface_NotifyUpdateCapacity_Params
{
	float                                              InBackPackCapacity;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InOccupiedCapacity;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InSafetyBoxCapacity;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InSafetyBoxOccupiedCapacity;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.ItemContainerOwnerInterface.NotifyItemUpdated
struct UItemContainerOwnerInterface_NotifyItemUpdated_Params
{
	struct FItemDefineID                               DefineID;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FBattleItemData                             ItemData;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Basic.ItemContainerOwnerInterface.NotifyItemRemoved
struct UItemContainerOwnerInterface_NotifyItemRemoved_Params
{
	struct FItemDefineID                               DefineID;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FBattleItemData                             ItemData;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Basic.ItemContainerOwnerInterface.NotifyItemEmpty
struct UItemContainerOwnerInterface_NotifyItemEmpty_Params
{
};

// Function Basic.ItemContainerOwnerInterface.NotifyItemAdded
struct UItemContainerOwnerInterface_NotifyItemAdded_Params
{
	struct FItemDefineID                               DefineID;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FBattleItemData                             ItemData;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Basic.LuaAsyncTasksSubsystem.IsNeedClear
struct ULuaAsyncTasksSubsystem_IsNeedClear_Params
{
	float                                              ClearMemorySize;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ClearArrayObjectSize;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSluaBPVar                                  Callback;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.LuaAsyncTaskSubsystem.IsNeedClear
struct ULuaAsyncTaskSubsystem_IsNeedClear_Params
{
	class UFrontendHUD*                                FrontendHUD;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSluaBPVar                                  Callback;                                                 // (Parm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.LuaEventBridgeFunction.UnRegisterEventByTarget
struct ULuaEventBridgeFunction_UnRegisterEventByTarget_Params
{
	class UObject*                                     ObjContext;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.LuaEventBridgeFunction.UnRegisterEvent
struct ULuaEventBridgeFunction_UnRegisterEvent_Params
{
	struct FString                                     FEventType;                                               // (Parm, ZeroConstructor)
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	class UObject*                                     ObjContext;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                EventHandle;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.LuaEventBridgeFunction.RegistEvent
struct ULuaEventBridgeFunction_RegistEvent_Params
{
	struct FString                                     EventType;                                                // (Parm, ZeroConstructor)
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	class UObject*                                     ObjContext;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     FunctionName;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.LuaEventBridge.SyncLuaRegisterEventNum
struct ULuaEventBridge_SyncLuaRegisterEventNum_Params
{
	struct FString                                     EventType;                                                // (Parm, ZeroConstructor)
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	int                                                Number;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.LuaEventBridge.GetCurrentParam
struct ULuaEventBridge_GetCurrentParam_Params
{
	TArray<class ULuaTemBPData*>                       ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.LuaEventBridge.DeactivateEventsByFilterKey
struct ULuaEventBridge_DeactivateEventsByFilterKey_Params
{
	uint32_t                                           FilterKey;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Basic.LuaEventBridge.CheckNeedPostEventWithFilterKey
struct ULuaEventBridge_CheckNeedPostEventWithFilterKey_Params
{
	uint32_t                                           FilterKey;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     EventType;                                                // (Parm, ZeroConstructor)
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	bool                                               bCheckNeedPostLua;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.LuaEventBridge.ActiveEventByFilterKey
struct ULuaEventBridge_ActiveEventByFilterKey_Params
{
	uint32_t                                           FilterKey;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     EventType;                                                // (Parm, ZeroConstructor)
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	bool                                               bActive;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.LuaEventSubsystem.UnRegistEvent
struct ULuaEventSubsystem_UnRegistEvent_Params
{
	int                                                EventHandle;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.LuaEventSubsystem.SetBridgeFunction
struct ULuaEventSubsystem_SetBridgeFunction_Params
{
	struct FSluaBPVar                                  OnRegistEvent;                                            // (Parm)
	struct FSluaBPVar                                  OnUnRegistEvent;                                          // (Parm)
	struct FSluaBPVar                                  OnPostEvent;                                              // (Parm)
	struct FSluaBPVar                                  OnPostBlueprintEvent;                                     // (Parm)
};

// Function Basic.LuaEventSubsystem.RegistEvent
struct ULuaEventSubsystem_RegistEvent_Params
{
	struct FString                                     EventID;                                                  // (Parm, ZeroConstructor)
	struct FString                                     EventType;                                                // (Parm, ZeroConstructor)
	class UObject*                                     Object;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     FunctionName;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.PlayerReliableSequentialSyncActor.OnActorSpawned
struct APlayerReliableSequentialSyncActor_OnActorSpawned_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.RenderFunctionLibrary.MarkComponentRenderStateDirty
struct URenderFunctionLibrary_MarkComponentRenderStateDirty_Params
{
	class UActorComponent*                             comp;                                                     // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.SetEndTime
struct USTBaseBuffCarrierInterface_SetEndTime_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              EndTime;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.RemoveBuffBySkill
struct USTBaseBuffCarrierInterface_RemoveBuffBySkill_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.RemoveBuffByID
struct USTBaseBuffCarrierInterface_RemoveBuffByID_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.HasSkillID
struct USTBaseBuffCarrierInterface_HasSkillID_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.HasBuffID
struct USTBaseBuffCarrierInterface_HasBuffID_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.GetBuffIDsBySkillID
struct USTBaseBuffCarrierInterface_GetBuffIDsBySkillID_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.STBaseBuffCarrierInterface.GetBuffDuration
struct USTBaseBuffCarrierInterface_GetBuffDuration_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.GetBuffComponent
struct USTBaseBuffCarrierInterface_GetBuffComponent_Params
{
	class USTBuffSystemComponent*                      ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.ChangeBuffDuration
struct USTBaseBuffCarrierInterface_ChangeBuffDuration_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Duration;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.AddBuffBySkill
struct USTBaseBuffCarrierInterface_AddBuffBySkill_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Level;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBaseBuffCarrierInterface.AddBuffByID
struct USTBaseBuffCarrierInterface_AddBuffByID_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Level;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuff.Tick
struct USTBuff_Tick_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              TimeSeconds;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        TickActionList;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function Basic.STBuff.ResetActionExecute
struct USTBuff_ResetActionExecute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuff.OnCreate
struct USTBuff_OnCreate_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuff.Initialize
struct USTBuff_Initialize_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuff.InitBuffAction
struct USTBuff_InitBuffAction_Params
{
};

// Function Basic.STBuff.End
struct USTBuff_End_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuff.Destroy
struct USTBuff_Destroy_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuff.ChangeNotify
struct USTBuff_ChangeNotify_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffNodeInstanceData.GetBuffInstLevel
struct USTBuffNodeInstanceData_GetBuffInstLevel_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffAction.ToString
struct USTBuffAction_ToString_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffAction.Tick
struct USTBuffAction_Tick_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.SetEnabled
struct USTBuffAction_SetEnabled_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Enabled;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.ResetExecute
struct USTBuffAction_ResetExecute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IgnoreEnd;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.OnTick
struct USTBuffAction_OnTick_Params
{
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.OnResetExecute
struct USTBuffAction_OnResetExecute_Params
{
	bool                                               IgnoreEnd;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.OnInitialize
struct USTBuffAction_OnInitialize_Params
{
};

// Function Basic.STBuffAction.OnExecute
struct USTBuffAction_OnExecute_Params
{
};

// Function Basic.STBuffAction.OnEnd
struct USTBuffAction_OnEnd_Params
{
};

// Function Basic.STBuffAction.OnDestroy
struct USTBuffAction_OnDestroy_Params
{
};

// Function Basic.STBuffAction.OnCheckLinkActionEnabled
struct USTBuffAction_OnCheckLinkActionEnabled_Params
{
};

// Function Basic.STBuffAction.OnChangeNotify
struct USTBuffAction_OnChangeNotify_Params
{
};

// Function Basic.STBuffAction.OnAsyncLoadSoftPathDone
struct USTBuffAction_OnAsyncLoadSoftPathDone_Params
{
};

// Function Basic.STBuffAction.IsRoleOK
struct USTBuffAction_IsRoleOK_Params
{
	class UActorComponent*                             OwnerComponent;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffAction.Initialize
struct USTBuffAction_Initialize_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.GetRealOwnerRole
struct USTBuffAction_GetRealOwnerRole_Params
{
	TEnumAsByte<enum ENetRole>                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffAction.GetOwner
struct USTBuffAction_GetOwner_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffAction.GetCauser
struct USTBuffAction_GetCauser_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffAction.Execute
struct USTBuffAction_Execute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.End
struct USTBuffAction_End_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.Destroy
struct USTBuffAction_Destroy_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.CheckLinkActionEnabled
struct USTBuffAction_CheckLinkActionEnabled_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction.ChangeNotify
struct USTBuffAction_ChangeNotify_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction_Lua.ToString
struct USTBuffAction_Lua_ToString_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffAction_Lua.OnTick
struct USTBuffAction_Lua_OnTick_Params
{
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffAction_Lua.OnInitialize
struct USTBuffAction_Lua_OnInitialize_Params
{
};

// Function Basic.STBuffAction_Lua.OnExecute
struct USTBuffAction_Lua_OnExecute_Params
{
};

// Function Basic.STBuffAction_Lua.OnEnd
struct USTBuffAction_Lua_OnEnd_Params
{
};

// Function Basic.STBuffAction_Lua.OnDestroy
struct USTBuffAction_Lua_OnDestroy_Params
{
};

// Function Basic.STBuffAction_Lua.OnChangeNotify
struct USTBuffAction_Lua_OnChangeNotify_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.Tick
struct USTBuffCheckConditionWrapper_Tick_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.ResetExecute
struct USTBuffCheckConditionWrapper_ResetExecute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IgnoreEnd;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.OnTick
struct USTBuffCheckConditionWrapper_OnTick_Params
{
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.OnInitialize
struct USTBuffCheckConditionWrapper_OnInitialize_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.OnDestroy
struct USTBuffCheckConditionWrapper_OnDestroy_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.OnConditionTrue
struct USTBuffCheckConditionWrapper_OnConditionTrue_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.OnConditionFalse
struct USTBuffCheckConditionWrapper_OnConditionFalse_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.OnChangeNotify
struct USTBuffCheckConditionWrapper_OnChangeNotify_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.IsRoleOK
struct USTBuffCheckConditionWrapper_IsRoleOK_Params
{
	class UActorComponent*                             OwnerComponent;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.InitLinkActionEnableState
struct USTBuffCheckConditionWrapper_InitLinkActionEnableState_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.Initialize
struct USTBuffCheckConditionWrapper_Initialize_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.GetRealOwnerRole
struct USTBuffCheckConditionWrapper_GetRealOwnerRole_Params
{
	TEnumAsByte<enum ENetRole>                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.Execute
struct USTBuffCheckConditionWrapper_Execute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.End
struct USTBuffCheckConditionWrapper_End_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.Destroy
struct USTBuffCheckConditionWrapper_Destroy_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCheckConditionWrapper.CheckCondition
struct USTBuffCheckConditionWrapper_CheckCondition_Params
{
};

// Function Basic.STBuffCheckConditionWrapper.ChangeNotify
struct USTBuffCheckConditionWrapper_ChangeNotify_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCondition.OnResetExecute
struct USTBuffCondition_OnResetExecute_Params
{
	bool                                               IgnoreEnd;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffCondition.OnInitialize
struct USTBuffCondition_OnInitialize_Params
{
};

// Function Basic.STBuffCondition.OnEnd
struct USTBuffCondition_OnEnd_Params
{
};

// Function Basic.STBuffCondition.OnDestroy
struct USTBuffCondition_OnDestroy_Params
{
};

// Function Basic.STBuffCondition.GetOwner
struct USTBuffCondition_GetOwner_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCondition.GetCauser
struct USTBuffCondition_GetCauser_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCondition.Copy
struct USTBuffCondition_Copy_Params
{
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuffCondition*                            ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffCondition.CheckIsTrue
struct USTBuffCondition_CheckIsTrue_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCondition.ChangeNotify
struct USTBuffCondition_ChangeNotify_Params
{
};

// Function Basic.STBuffConditionComplex.OnInitialize
struct USTBuffConditionComplex_OnInitialize_Params
{
};

// Function Basic.STBuffConditionComplex.OnDestroy
struct USTBuffConditionComplex_OnDestroy_Params
{
};

// Function Basic.STBuffConditionComplex.Copy
struct USTBuffConditionComplex_Copy_Params
{
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuffCondition*                            ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffConditionComplex.CheckIsTrue
struct USTBuffConditionComplex_CheckIsTrue_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffConditionNot.OnInitialize
struct USTBuffConditionNot_OnInitialize_Params
{
};

// Function Basic.STBuffConditionNot.OnDestroy
struct USTBuffConditionNot_OnDestroy_Params
{
};

// Function Basic.STBuffConditionNot.Copy
struct USTBuffConditionNot_Copy_Params
{
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuffCondition*                            ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffConditionNot.CheckIsTrue
struct USTBuffConditionNot_CheckIsTrue_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffCondition_Lua.OnInitialize
struct USTBuffCondition_Lua_OnInitialize_Params
{
};

// Function Basic.STBuffCondition_Lua.OnDestroy
struct USTBuffCondition_Lua_OnDestroy_Params
{
};

// Function Basic.STBuffCondition_Lua.CheckIsTrue
struct USTBuffCondition_Lua_CheckIsTrue_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffConditionAction.OnTick
struct USTBuffConditionAction_OnTick_Params
{
	float                                              DetalTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffConditionAction.OnInitialize
struct USTBuffConditionAction_OnInitialize_Params
{
};

// Function Basic.STBuffConditionAction.OnDestroy
struct USTBuffConditionAction_OnDestroy_Params
{
};

// Function Basic.STBuffConditionAction.OnConditionTrue
struct USTBuffConditionAction_OnConditionTrue_Params
{
};

// Function Basic.STBuffConditionAction.OnConditionFalse
struct USTBuffConditionAction_OnConditionFalse_Params
{
};

// Function Basic.STBuffConditionAction.OnChangeNotify
struct USTBuffConditionAction_OnChangeNotify_Params
{
};

// Function Basic.STBuffConditionAction.CheckCondition
struct USTBuffConditionAction_CheckCondition_Params
{
};

// Function Basic.STBuffEvent.TriggerEvent
struct USTBuffEvent_TriggerEvent_Params
{
};

// Function Basic.STBuffEvent.ToString
struct USTBuffEvent_ToString_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffEvent.SetTimer
struct USTBuffEvent_SetTimer_Params
{
	struct FName                                       FunctionName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRate;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               InbLoop;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InFirstDelay;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffEvent.OnInitialize
struct USTBuffEvent_OnInitialize_Params
{
};

// Function Basic.STBuffEvent.OnEnd
struct USTBuffEvent_OnEnd_Params
{
};

// Function Basic.STBuffEvent.OnDestroy
struct USTBuffEvent_OnDestroy_Params
{
};

// Function Basic.STBuffEvent.IsRoleOK
struct USTBuffEvent_IsRoleOK_Params
{
	class UActorComponent*                             OwnerComponent;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffEvent.GetRealOwnerRole
struct USTBuffEvent_GetRealOwnerRole_Params
{
	TEnumAsByte<enum ENetRole>                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffEvent.GetOwner
struct USTBuffEvent_GetOwner_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffEvent.GetCauser
struct USTBuffEvent_GetCauser_Params
{
	class AActor*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffEvent.Copy
struct USTBuffEvent_Copy_Params
{
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuffEvent*                                ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffEvent.ClearTimer
struct USTBuffEvent_ClearTimer_Params
{
	struct FName                                       FunctionName;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffEvent.ClearAllTimer
struct USTBuffEvent_ClearAllTimer_Params
{
};

// Function Basic.STBuffEvent_Lua.ToString
struct USTBuffEvent_Lua_ToString_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffEvent_Multi.OnInitialize
struct USTBuffEvent_Multi_OnInitialize_Params
{
};

// Function Basic.STBuffEvent_Multi.OnEnd
struct USTBuffEvent_Multi_OnEnd_Params
{
};

// Function Basic.STBuffEvent_Multi.OnDestroy
struct USTBuffEvent_Multi_OnDestroy_Params
{
};

// Function Basic.STBuffEvent_Multi.Copy
struct USTBuffEvent_Multi_Copy_Params
{
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuffEvent*                                ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetVectorShared
struct USTBuffSharedInterface_SetVectorShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FVector                                     InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetUInt8Shared
struct USTBuffSharedInterface_SetUInt8Shared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	unsigned char                                      InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetTargetShared
struct USTBuffSharedInterface_SetTargetShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	TArray<class AActor*>                              InActors;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.STBuffSharedInterface.SetStringShared
struct USTBuffSharedInterface_SetStringShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FString                                     InValue;                                                  // (Parm, ZeroConstructor)
};

// Function Basic.STBuffSharedInterface.SetRotatorShared
struct USTBuffSharedInterface_SetRotatorShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FRotator                                    InValue;                                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetNameShared
struct USTBuffSharedInterface_SetNameShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FName                                       InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetInt32Shared
struct USTBuffSharedInterface_SetInt32Shared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	int                                                InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetFloatShared
struct USTBuffSharedInterface_SetFloatShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	float                                              InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.SetBooleanShared
struct USTBuffSharedInterface_SetBooleanShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	bool                                               InValue;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.RemoveShared
struct USTBuffSharedInterface_RemoveShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
};

// Function Basic.STBuffSharedInterface.GetVectorShared
struct USTBuffSharedInterface_GetVectorShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FVector                                     OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetUInt8Shared
struct USTBuffSharedInterface_GetUInt8Shared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	unsigned char                                      OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetTargetShared
struct USTBuffSharedInterface_GetTargetShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	TArray<class AActor*>                              OutActors;                                                // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetStringShared
struct USTBuffSharedInterface_GetStringShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FString                                     OutValue;                                                 // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetRotatorShared
struct USTBuffSharedInterface_GetRotatorShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FRotator                                    OutValue;                                                 // (Parm, OutParm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetNameShared
struct USTBuffSharedInterface_GetNameShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	struct FName                                       OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetInt32Shared
struct USTBuffSharedInterface_GetInt32Shared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	int                                                OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetFloatShared
struct USTBuffSharedInterface_GetFloatShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	float                                              OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSharedInterface.GetBooleanShared
struct USTBuffSharedInterface_GetBooleanShared_Params
{
	struct FString                                     SharedName;                                               // (Parm, ZeroConstructor)
	bool                                               OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.UpdateClientBuff
struct USTBuffSystemComponent_UpdateClientBuff_Params
{
	struct FBuffSyncBrief                              Brief;                                                    // (Parm, OutParm)
};

// Function Basic.STBuffSystemComponent.SetEndTime
struct USTBuffSystemComponent_SetEndTime_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              EndTime;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.SetBuffReplaceData
struct USTBuffSystemComponent_SetBuffReplaceData_Params
{
	struct FBuffReplaceData                            From;                                                     // (Parm)
	struct FBuffReplaceData                            To;                                                       // (Parm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.RemoveBuffBySkill
struct USTBuffSystemComponent_RemoveBuffBySkill_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.RemoveBuff
struct USTBuffSystemComponent_RemoveBuff_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.RemoveAllBuffsWithExcludeArray
struct USTBuffSystemComponent_RemoveAllBuffsWithExcludeArray_Params
{
	TArray<int>                                        InExcludeArry;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.STBuffSystemComponent.RemoveAllBuffs
struct USTBuffSystemComponent_RemoveAllBuffs_Params
{
	bool                                               bClearAll;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Basic.STBuffSystemComponent.OnUpdateBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnUpdateBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.OnRep_SyncBriefs
struct USTBuffSystemComponent_OnRep_SyncBriefs_Params
{
};

// Function Basic.STBuffSystemComponent.OnRep_OwnerSyncBriefs
struct USTBuffSystemComponent_OnRep_OwnerSyncBriefs_Params
{
};

// DelegateFunction Basic.STBuffSystemComponent.OnRemoveBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnRemoveBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Basic.STBuffSystemComponent.OnClientUpdateBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnClientUpdateBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Basic.STBuffSystemComponent.OnClientRemoveBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnClientRemoveBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Basic.STBuffSystemComponent.OnClientAddBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnClientAddBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Basic.STBuffSystemComponent.OnAddBuffEvent__DelegateSignature
struct USTBuffSystemComponent_OnAddBuffEvent__DelegateSignature_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsExist;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.IsCDOK
struct USTBuffSystemComponent_IsCDOK_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.IsBuffInstExist
struct USTBuffSystemComponent_IsBuffInstExist_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.HasSkillID
struct USTBuffSystemComponent_HasSkillID_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.HasBuff
struct USTBuffSystemComponent_HasBuff_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetSubsystem
struct USTBuffSystemComponent_GetSubsystem_Params
{
	class UBuffConfigSubsystem*                        ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetSTBuffByBuffID
struct USTBuffSystemComponent_GetSTBuffByBuffID_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class USTBuff*                                     ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetRealOwnerRoleSafety
struct USTBuffSystemComponent_GetRealOwnerRoleSafety_Params
{
	TEnumAsByte<enum ENetRole>                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetBuffReplaceDataByID
struct USTBuffSystemComponent_GetBuffReplaceDataByID_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bBuffInst;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBuffReplaceData                            ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

// Function Basic.STBuffSystemComponent.GetBuffLayerCount
struct USTBuffSystemComponent_GetBuffLayerCount_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetBuffInfoBySkillID
struct USTBuffSystemComponent_GetBuffInfoBySkillID_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FBuffSyncBrief>                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffSystemComponent.GetBuffInfoByBuffID
struct USTBuffSystemComponent_GetBuffInfoByBuffID_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FBuffSyncBrief>                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffSystemComponent.GetBuffInfo
struct USTBuffSystemComponent_GetBuffInfo_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBuffSyncBrief                              OutBuff;                                                  // (Parm, OutParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetBuffIDsBySkillID
struct USTBuffSystemComponent_GetBuffIDsBySkillID_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.STBuffSystemComponent.GetBuffDuration
struct USTBuffSystemComponent_GetBuffDuration_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetBuffDSEndTime
struct USTBuffSystemComponent_GetBuffDSEndTime_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.GetBuffCDInfo
struct USTBuffSystemComponent_GetBuffCDInfo_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffSystemComponent.GetAllBuffInfo
struct USTBuffSystemComponent_GetAllBuffInfo_Params
{
	TArray<struct FBuffSyncBrief>                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.STBuffSystemComponent.DoCooldown
struct USTBuffSystemComponent_DoCooldown_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bReset;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.ClearBuffs
struct USTBuffSystemComponent_ClearBuffs_Params
{
};

// Function Basic.STBuffSystemComponent.ChangeLevel
struct USTBuffSystemComponent_ChangeLevel_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                NewLevel;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.ChangeDuration
struct USTBuffSystemComponent_ChangeDuration_Params
{
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Duration;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.AddBuffBySkill
struct USTBuffSystemComponent_AddBuffBySkill_Params
{
	int                                                SkillID;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Level;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffSystemComponent.AddBuff
struct USTBuffSystemComponent_AddBuff_Params
{
	int                                                BuffID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Causer;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                LayerCount;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                CauseSkillID;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Level;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.Tick
struct USTBuffTriggerBase_Tick_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DeltaTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.ResetExecute
struct USTBuffTriggerBase_ResetExecute_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.OnTriggerCreate
struct USTBuffTriggerBase_OnTriggerCreate_Params
{
};

// Function Basic.STBuffTriggerBase.OnTick
struct USTBuffTriggerBase_OnTick_Params
{
	float                                              DeltaTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.OnInitialize
struct USTBuffTriggerBase_OnInitialize_Params
{
};

// Function Basic.STBuffTriggerBase.OnEnd
struct USTBuffTriggerBase_OnEnd_Params
{
};

// Function Basic.STBuffTriggerBase.OnDestroy
struct USTBuffTriggerBase_OnDestroy_Params
{
};

// Function Basic.STBuffTriggerBase.OnCreate
struct USTBuffTriggerBase_OnCreate_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.IsRoleOK
struct USTBuffTriggerBase_IsRoleOK_Params
{
	class UActorComponent*                             OwnerComponent;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.IsNeedTick
struct USTBuffTriggerBase_IsNeedTick_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.InitLinkActionEnableState
struct USTBuffTriggerBase_InitLinkActionEnableState_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.Initialize
struct USTBuffTriggerBase_Initialize_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.GetRealOwnerRole
struct USTBuffTriggerBase_GetRealOwnerRole_Params
{
	TEnumAsByte<enum ENetRole>                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.End
struct USTBuffTriggerBase_End_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.STBuffTriggerBase.Destroy
struct USTBuffTriggerBase_Destroy_Params
{
	class UActorComponent*                             BuffSystemComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InstID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TableManagerSubsystem.SetTableStringDataField
struct UTableManagerSubsystem_SetTableStringDataField_Params
{
	struct FName                                       tableName;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     Key;                                                      // (Parm, ZeroConstructor)
	struct FString                                     Field;                                                    // (Parm, ZeroConstructor)
	struct FString                                     NewValue;                                                 // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TableManagerSubsystem.SetModName
struct UTableManagerSubsystem_SetModName_Params
{
	struct FString                                     ModName;                                                  // (Parm, ZeroConstructor)
};

// Function Basic.TableManagerSubsystem.GetTableProxy
struct UTableManagerSubsystem_GetTableProxy_Params
{
	struct FName                                       tableName;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTempory;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SystemName;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SubModName;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPreLoadPathCompression;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UDataTableProxy*                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TableManagerSubsystem.GetTableDataField
struct UTableManagerSubsystem_GetTableDataField_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	struct FTableRowBase                               Key;                                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     Field;                                                    // (Parm, ZeroConstructor)
	struct FTableRowBase                               Out;                                                      // (Parm, OutParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TableManagerSubsystem.GetTableData
struct UTableManagerSubsystem_GetTableData_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	struct FString                                     Key;                                                      // (Parm, ZeroConstructor)
	struct FTableRowBase                               OutRow;                                                   // (Parm, OutParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.ShouldForceEnableAnimUpdateRateOptimizations
struct UTickOptimizationAnimComponent_ShouldForceEnableAnimUpdateRateOptimizations_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.SetNonRenderedFramesSkipped
struct UTickOptimizationAnimComponent_SetNonRenderedFramesSkipped_Params
{
	int                                                InNonRenderedFramesSkipped;                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.SetMaxFramesSkippedForInterpolation
struct UTickOptimizationAnimComponent_SetMaxFramesSkippedForInterpolation_Params
{
	int                                                InMaxFramesSkippedForInterpolation;                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.SetLODToFramesSkipped
struct UTickOptimizationAnimComponent_SetLODToFramesSkipped_Params
{
	TArray<int>                                        InLODToFramesSkipped;                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.TickOptimizationAnimComponent.SetFramesSkippedScreenSizeThresholds
struct UTickOptimizationAnimComponent_SetFramesSkippedScreenSizeThresholds_Params
{
	TArray<float>                                      InFramesSkippedScreenSizeThresholds;                      // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.TickOptimizationAnimComponent.SetForceEnableAnimUpdateRateOptimizations
struct UTickOptimizationAnimComponent_SetForceEnableAnimUpdateRateOptimizations_Params
{
	bool                                               bInForceEnableAnimUpdateRateOptimizations;                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.SetAnimUpdateRateOptimizationsMode
struct UTickOptimizationAnimComponent_SetAnimUpdateRateOptimizationsMode_Params
{
	ETickOptimizationAnimUROMode                       InAnimUpdateRateOptimizationsMode;                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.RegisterDynamicSkinnedMeshComponent
struct UTickOptimizationAnimComponent_RegisterDynamicSkinnedMeshComponent_Params
{
	class USkinnedMeshComponent*                       SkinnedMeshComponent;                                     // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.GetNonRenderedFramesSkipped
struct UTickOptimizationAnimComponent_GetNonRenderedFramesSkipped_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.GetMaxFramesSkippedForInterpolation
struct UTickOptimizationAnimComponent_GetMaxFramesSkippedForInterpolation_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationAnimComponent.GetLODToFramesSkipped
struct UTickOptimizationAnimComponent_GetLODToFramesSkipped_Params
{
	TArray<int>                                        ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.TickOptimizationAnimComponent.GetFramesSkippedScreenSizeThresholds
struct UTickOptimizationAnimComponent_GetFramesSkippedScreenSizeThresholds_Params
{
	TArray<float>                                      ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.TickOptimizationAnimComponent.GetAnimUpdateRateOptimizationsMode
struct UTickOptimizationAnimComponent_GetAnimUpdateRateOptimizationsMode_Params
{
	ETickOptimizationAnimUROMode                       ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationFocusComponent.ShouldTrack
struct UTickOptimizationFocusComponent_ShouldTrack_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.ShouldForceExecuteFirstTick
struct UTickOptimizationTargetComponent_ShouldForceExecuteFirstTick_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetTickSettings
struct UTickOptimizationTargetComponent_SetTickSettings_Params
{
	TArray<struct FTickOptimizationTickSettings>       InTickSettings;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.TickOptimizationTargetComponent.SetSphereRadius
struct UTickOptimizationTargetComponent_SetSphereRadius_Params
{
	float                                              InRadius;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetMidZoneSizes
struct UTickOptimizationTargetComponent_SetMidZoneSizes_Params
{
	TArray<float>                                      InMidZoneSizes;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Basic.TickOptimizationTargetComponent.SetForceExecuteFirstTick
struct UTickOptimizationTargetComponent_SetForceExecuteFirstTick_Params
{
	bool                                               bInForceExecuteFirstTick;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetDistanceMode
struct UTickOptimizationTargetComponent_SetDistanceMode_Params
{
	ETickOptimizationDistanceMode                      InDistanceMode;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetComponentsTickControl
struct UTickOptimizationTargetComponent_SetComponentsTickControl_Params
{
	bool                                               bInComponentsTickControl;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetBufferSize
struct UTickOptimizationTargetComponent_SetBufferSize_Params
{
	float                                              InBufferSize;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.SetActorTickControl
struct UTickOptimizationTargetComponent_SetActorTickControl_Params
{
	bool                                               bInActorTickControl;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.RemoveComponentTickControl
struct UTickOptimizationTargetComponent_RemoveComponentTickControl_Params
{
	class UActorComponent*                             Component;                                                // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.Release
struct UTickOptimizationTargetComponent_Release_Params
{
};

// Function Basic.TickOptimizationTargetComponent.IsForced
struct UTickOptimizationTargetComponent_IsForced_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.IsComponentsTickControl
struct UTickOptimizationTargetComponent_IsComponentsTickControl_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.IsActorTickControl
struct UTickOptimizationTargetComponent_IsActorTickControl_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.GetTickZone
struct UTickOptimizationTargetComponent_GetTickZone_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.GetTickSettings
struct UTickOptimizationTargetComponent_GetTickSettings_Params
{
	TArray<struct FTickOptimizationTickSettings>       ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.TickOptimizationTargetComponent.GetSphereRadius
struct UTickOptimizationTargetComponent_GetSphereRadius_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.GetMidZoneSizes
struct UTickOptimizationTargetComponent_GetMidZoneSizes_Params
{
	TArray<float>                                      ReturnValue;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function Basic.TickOptimizationTargetComponent.GetDistanceMode
struct UTickOptimizationTargetComponent_GetDistanceMode_Params
{
	ETickOptimizationDistanceMode                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.GetBufferSize
struct UTickOptimizationTargetComponent_GetBufferSize_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.Force
struct UTickOptimizationTargetComponent_Force_Params
{
	int                                                InZone;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.TickOptimizationTargetComponent.AddComponentTickControl
struct UTickOptimizationTargetComponent_AddComponentTickControl_Params
{
	class UActorComponent*                             Component;                                                // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Basic.BPTable.GetWrapperPath
struct UBPTable_GetWrapperPath_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.BPTable.GetWrapperClass
struct UBPTable_GetWrapperClass_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.GetPath
struct UBPTable_GetPath_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bForceLobby;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.BPTable.GetObject
struct UBPTable_GetObject_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLowDevice;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.GetModObject
struct UBPTable_GetModObject_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.GetModClass
struct UBPTable_GetModClass_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.GetCustom1Class
struct UBPTable_GetCustom1Class_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.GetClass
struct UBPTable_GetClass_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLowDevice;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.BPTable.ConvertPath
struct UBPTable_ConvertPath_Params
{
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.InitTableData
struct UUAELoadedClassManager_InitTableData_Params
{
};

// Function Basic.UAELoadedClassManager.InitialModTableItemMap
struct UUAELoadedClassManager_InitialModTableItemMap_Params
{
};

// Function Basic.UAELoadedClassManager.InitBPTableMap_Mod
struct UUAELoadedClassManager_InitBPTableMap_Mod_Params
{
};

// Function Basic.UAELoadedClassManager.InitBPTableMap
struct UUAELoadedClassManager_InitBPTableMap_Params
{
};

// Function Basic.UAELoadedClassManager.HandleTableModNameChanged
struct UUAELoadedClassManager_HandleTableModNameChanged_Params
{
	struct FString                                     InModName;                                                // (Parm, ZeroConstructor)
};

// Function Basic.UAELoadedClassManager.GetWrapperPath
struct UUAELoadedClassManager_GetWrapperPath_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAELoadedClassManager.GetWrapperClass
struct UUAELoadedClassManager_GetWrapperClass_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetPath
struct UUAELoadedClassManager_GetPath_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bForceLobby;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAELoadedClassManager.GetObject
struct UUAELoadedClassManager_GetObject_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     Outer;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLowDevice;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject*                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetExactDeviceLevel
struct UUAELoadedClassManager_GetExactDeviceLevel_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetDeviceLevel
struct UUAELoadedClassManager_GetDeviceLevel_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetCustom1Class
struct UUAELoadedClassManager_GetCustom1Class_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetClassLoadingPath
struct UUAELoadedClassManager_GetClassLoadingPath_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAELoadedClassManager.GetClass
struct UUAELoadedClassManager_GetClass_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	int                                                ID;                                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLobby;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsLowDevice;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.GetBPTableName
struct UUAELoadedClassManager_GetBPTableName_Params
{
	int                                                Type;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAELoadedClassManager.GetAssetByAssetReferenceAsync
struct UUAELoadedClassManager_GetAssetByAssetReferenceAsync_Params
{
	struct FSoftObjectPath                             AssetReference;                                           // (Parm)
	struct FScriptDelegate                             AssetLoadSuccessDelegate;                                 // (Parm, ZeroConstructor)
};

// Function Basic.UAELoadedClassManager.GetAssetAsyncWithStringForManage
struct UUAELoadedClassManager_GetAssetAsyncWithStringForManage_Params
{
	struct FSoftObjectPath                             AssetReference;                                           // (Parm)
	struct FString                                     InputString;                                              // (Parm, ZeroConstructor)
	struct FScriptDelegate                             AssetLoadSuccessDelegate;                                 // (Parm, ZeroConstructor)
};

// Function Basic.UAELoadedClassManager.Get
struct UUAELoadedClassManager_Get_Params
{
	class UUAELoadedClassManager*                      ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.CreateAndAddBPTable_Mod
struct UUAELoadedClassManager_CreateAndAddBPTable_Mod_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	class UBPTable*                                    ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.CreateAndAddBPTable
struct UUAELoadedClassManager_CreateAndAddBPTable_Params
{
	struct FString                                     BPTableName;                                              // (Parm, ZeroConstructor)
	class UBPTable*                                    ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAELoadedClassManager.ClearModTableItemMap
struct UUAELoadedClassManager_ClearModTableItemMap_Params
{
};

// Function Basic.UAELoadedClassManager.ClearBPTable_Mod
struct UUAELoadedClassManager_ClearBPTable_Mod_Params
{
};

// Function Basic.UAELoadedClassManager.ClearBPTable
struct UUAELoadedClassManager_ClearBPTable_Params
{
};

// Function Basic.UAELoadedClassManager.ClearAssetByAssetReferenceAsync
struct UUAELoadedClassManager_ClearAssetByAssetReferenceAsync_Params
{
	struct FScriptDelegate                             AssetLoadSuccessDelegate;                                 // (Parm, ZeroConstructor)
};

// Function Basic.UAELoadedClassManager.ClearAllHandle
struct UUAELoadedClassManager_ClearAllHandle_Params
{
};

// Function Basic.UAELoadedClassManager.ClearAllData
struct UUAELoadedClassManager_ClearAllData_Params
{
};

// Function Basic.UAEMeshComponent.TriggerCacheMaterialParameterNameIndices
struct UUAEMeshComponent_TriggerCacheMaterialParameterNameIndices_Params
{
};

// Function Basic.UAEMeshComponent.RemoveDisableClothRequest
struct UUAEMeshComponent_RemoveDisableClothRequest_Params
{
	struct FString                                     InSource;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.UAEMeshComponent.GetPredictedLODLevel
struct UUAEMeshComponent_GetPredictedLODLevel_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAEMeshComponent.GetAnimUpdateParamsInfo
struct UUAEMeshComponent_GetAnimUpdateParamsInfo_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAEMeshComponent.AddDisableClothRequest
struct UUAEMeshComponent_AddDisableClothRequest_Params
{
	struct FString                                     InSource;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.UAENetConnection.IsClosed
struct UUAENetConnection_IsClosed_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAENetConnection.HasSameRegion
struct UUAENetConnection_HasSameRegion_Params
{
	struct FVector                                     OldLoc;                                                   // (Parm, IsPlainOldData)
	struct FVector                                     NewLoc;                                                   // (Parm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAENetConnection.ForceRefreshRegionWeakNetUpdateObjects
struct UUAENetConnection_ForceRefreshRegionWeakNetUpdateObjects_Params
{
	float                                              WeakNetConsiderFrequency;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UAETableManager.ReleaseTable
struct UUAETableManager_ReleaseTable_Params
{
	struct FName                                       TableFName;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UAETableManager.PreloadDataTablesAsync
struct UUAETableManager_PreloadDataTablesAsync_Params
{
};

// Function Basic.UAETableManager.GetTablePtr_Mod
struct UUAETableManager_GetTablePtr_Mod_Params
{
	struct FName                                       tableName;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetTablePtr
struct UUAETableManager_GetTablePtr_Params
{
	struct FName                                       tableName;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bCheckModTable;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetTableMap
struct UUAETableManager_GetTableMap_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	class UBaseTableResMap*                            ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetTableData
struct UUAETableManager_GetTableData_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	struct FString                                     Key;                                                      // (Parm, ZeroConstructor)
	struct FTableRowBase                               OutRow;                                                   // (Parm, OutParm)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetInstance
struct UUAETableManager_GetInstance_Params
{
	class UUAETableManager*                            ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetDomainByID
struct UUAETableManager_GetDomainByID_Params
{
	int                                                ID;                                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UAETableManager.GetDataTableStatic_Mod
struct UUAETableManager_GetDataTableStatic_Mod_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetDataTableStatic
struct UUAETableManager_GetDataTableStatic_Params
{
	struct FString                                     tableName;                                                // (Parm, ZeroConstructor)
	class UUAEDataTable*                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UAETableManager.GetDataTableProxy
struct UUAETableManager_GetDataTableProxy_Params
{
	struct FName                                       tableName;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTempory;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SystemName;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SubModName;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class UDataTableProxy*                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UELanguageUtilityMethods.SetDownLoadLanguageName
struct UUELanguageUtilityMethods_SetDownLoadLanguageName_Params
{
	struct FString                                     Language;                                                 // (Parm, ZeroConstructor)
};

// Function Basic.UELanguageUtilityMethods.IsJaguar
struct UUELanguageUtilityMethods_IsJaguar_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UELanguageUtilityMethods.GetPublishRegion
struct UUELanguageUtilityMethods_GetPublishRegion_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UELanguageUtilityMethods.GetDownLoadLanguageName
struct UUELanguageUtilityMethods_GetDownLoadLanguageName_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UELanguageUtilityMethods.GetCurrentLanguageName
struct UUELanguageUtilityMethods_GetCurrentLanguageName_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UELanguageUtilityMethods.ConvertLanguageName
struct UUELanguageUtilityMethods_ConvertLanguageName_Params
{
	struct FString                                     prelanguage;                                              // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UELanguageUtilityMethods.CheckLocalizationExist
struct UUELanguageUtilityMethods_CheckLocalizationExist_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.VectorNormalizeMultiple
struct UUEMathUtilityMethods_VectorNormalizeMultiple_Params
{
	struct FVector                                     Out;                                                      // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     v1;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float                                              Multiple;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.VectorMultiple
struct UUEMathUtilityMethods_VectorMultiple_Params
{
	struct FVector                                     Out;                                                      // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     v1;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float                                              Multiple;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.VectorMinus
struct UUEMathUtilityMethods_VectorMinus_Params
{
	struct FVector                                     Out;                                                      // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     v1;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     v2;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.VectorAdditive
struct UUEMathUtilityMethods_VectorAdditive_Params
{
	struct FVector                                     Out;                                                      // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     v1;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     v2;                                                       // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.FilterOKForCurrentMode
struct UUEMathUtilityMethods_FilterOKForCurrentMode_Params
{
	unsigned char                                      ModeType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ModeOpenFlag;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ModeTypes;                                                // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.Conv_VectorToRotator
struct UUEMathUtilityMethods_Conv_VectorToRotator_Params
{
	struct FRotator                                    Out;                                                      // (Parm, OutParm, IsPlainOldData)
	struct FVector                                     Vec;                                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.CalculateAngleToTargetAngle
struct UUEMathUtilityMethods_CalculateAngleToTargetAngle_Params
{
	float                                              StartAngle;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              targetAngle;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StepAngle;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	EAngleRotationDirectionType                        Dir;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.BKDRHash
struct UUEMathUtilityMethods_BKDRHash_Params
{
	struct FString                                     StrToHash;                                                // (Parm, ZeroConstructor)
	int                                                Mod;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEMathUtilityMethods.AngleDis
struct UUEMathUtilityMethods_AngleDis_Params
{
	float                                              angleA;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              angleB;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEPathUtilityMethods.IsPathExist
struct UUEPathUtilityMethods_IsPathExist_Params
{
	struct FString                                     HandlePath;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEPathUtilityMethods.IsAvatarResPathExistRetODPakName
struct UUEPathUtilityMethods_IsAvatarResPathExistRetODPakName_Params
{
	struct FString                                     HandlePath;                                               // (Parm, ZeroConstructor)
	struct FString                                     OutODPakName;                                             // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEPathUtilityMethods.IsAvatarResPathExist
struct UUEPathUtilityMethods_IsAvatarResPathExist_Params
{
	struct FString                                     HandlePath;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEPathUtilityMethods.GetPassiveDownloadResourcePaths
struct UUEPathUtilityMethods_GetPassiveDownloadResourcePaths_Params
{
	TArray<struct FString>                             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UEPathUtilityMethods.GetPassiveDownloadResourceIDList
struct UUEPathUtilityMethods_GetPassiveDownloadResourceIDList_Params
{
	TArray<int>                                        ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UEPathUtilityMethods.GetODPakFileName
struct UUEPathUtilityMethods_GetODPakFileName_Params
{
	struct FString                                     InODPakPath;                                              // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UEPathUtilityMethods.GetModName
struct UUEPathUtilityMethods_GetModName_Params
{
	class UObject*                                     WorldContext;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Basic.UEPathUtilityMethods.GetFullModName
struct UUEPathUtilityMethods_GetFullModName_Params
{
	class UObject*                                     WorldContext;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     MainMod;                                                  // (Parm, OutParm, ZeroConstructor)
	struct FString                                     SubMod;                                                   // (Parm, OutParm, ZeroConstructor)
};

// Function Basic.UEPathUtilityMethods.FilterOKForCurrentModeString
struct UUEPathUtilityMethods_FilterOKForCurrentModeString_Params
{
	struct FString                                     CurrentModeString;                                        // (Parm, ZeroConstructor)
	struct FString                                     CurrentExtraModeString;                                   // (Parm, ZeroConstructor)
	struct FString                                     ModStringInfo;                                            // (Parm, ZeroConstructor)
	unsigned char                                      ModeType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ModeOpenFlag;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Basic.UEPathUtilityMethods.ClearPassiveDownloadResourcePaths
struct UUEPathUtilityMethods_ClearPassiveDownloadResourcePaths_Params
{
};

// Function Basic.UEPathUtilityMethods.ClearPassiveDownloadResourceIDList
struct UUEPathUtilityMethods_ClearPassiveDownloadResourceIDList_Params
{
};

// Function Basic.UEPathUtilityMethods.AddPassiveResourceDownloadFlag
struct UUEPathUtilityMethods_AddPassiveResourceDownloadFlag_Params
{
	int                                                ItemId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

}

